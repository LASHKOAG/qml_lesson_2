function func() {
    console.log("Hello from js!");
}


function func_btn_2() {
    console.log("Hello from js and btn2!");

}


function func_btn_3() {
    console.log("Hello from js (btn3)!");
}

